from setuptools import setup, find_packages

setup(
    name='ordenamiento',  # Nombre del paquete
    version='1.2',
    packages=find_packages(),  # Busca todas las subcarpetas con archivos __init__.py
    install_requires=[],  # Si tienes dependencias adicionales, agrégalas aquí
)
