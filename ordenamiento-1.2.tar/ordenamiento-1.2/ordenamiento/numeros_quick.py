def quick_sort(arr, steps=None):
    if steps is None:
        steps = []
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    result = quick_sort(left, steps) + middle + quick_sort(right, steps)
    steps.append(result.copy())  # Guardar cada paso
    print("Pasos de Quicksort:", steps)
    return result